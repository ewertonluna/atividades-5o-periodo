package xyz.rafaelri.transito;

public interface ControladorCruzamento {
	public void entrarHorizontal();
	public void sairHorizontal();
	public void entrarVertical();
	public void sairVertical();
}
